A LITTLE DIWALI SURPRISE

OPEN IN ECLIPSE
1. Extract diwali_surprise_website.zip.
2. In Eclipse choose File > Import > General > Existing Projects into Workspace.
3. If Eclipse does not detect a project, create a General Project named diwali_surprise and copy the extracted files into it.
4. Open index.html and choose Open With > Web Browser. You can also double-click index.html to preview locally.

PUBLISH FOR ANDROID + IPHONE
This is a static website and needs no Java backend or database.
1. Visit https://app.netlify.com/drop and sign in/create a free account.
2. Drag the extracted diwali_surprise folder (the folder containing index.html) onto the upload area.
3. Netlify will provide a public HTTPS link. Open it on Android/iPhone or share it with her.
4. Change the site name in Netlify site settings if you want a prettier link.

PERSONALIZE
- Edit the note in index.html before sharing.
- Replace the files in assets while keeping their filenames to change the photos/videos.
- Test the page and both videos on your phone before sending.
- Share photos/videos only if she is comfortable having them included in a private surprise page.

The Instagram reference reel could not be fetched in this environment, so this is an original Diwali-inspired design, not an exact recreation.
