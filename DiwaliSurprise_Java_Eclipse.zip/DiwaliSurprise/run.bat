@echo off
cd /d "%~dp0"
java --add-modules jdk.httpserver -cp bin com.diwali.DiwaliServer
pause
