DIWALI SURPRISE - JAVA ECLIPSE PROJECT

WHAT IS INCLUDED
- Java HTTP server source: src/com/diwali/DiwaliServer.java
- Website: web/index.html, web/style.css, web/script.js
- Your two photos and two videos are inside web/assets/
- Eclipse project files are included.

OPEN IN ECLIPSE
1. Extract this ZIP.
2. Open Eclipse.
3. Select File > Import > General > Existing Projects into Workspace.
4. Choose the extracted DiwaliSurprise folder and finish.
5. Use JDK 11 or newer.
6. Open DiwaliServer.java and click Run.

OPEN THE WEBSITE
- On the computer: http://localhost:8080
- To open on Android/iPhone on the SAME Wi-Fi:
  1. Find your computer's local IPv4 address.
     Windows: open Command Prompt and run: ipconfig
     Look for IPv4 Address under the active Wi-Fi adapter.
  2. On the phone, open http://COMPUTER-IP:8080
     Example format: http://192.168.1.5:8080
  3. Allow Java through Windows Firewall if prompted.
  4. Keep the Java program running.

IMPORTANT: This local Java server link only works while your computer is on and
the phone is on the same Wi-Fi network. It is not a public internet link.

TO CREATE A SHAREABLE PUBLIC LINK
The site is static and can be hosted publicly without running Java. Upload the
entire "web" folder to a static hosting service such as Netlify Drop:
https://app.netlify.com/drop
The hosting service will provide an HTTPS link that can open on Android and iPhone
from anywhere. Do not upload private media unless you have permission to share it.

CUSTOMIZE
Edit web/index.html for the message. Replace media in web/assets while keeping
the same filenames, or update the paths in index.html.
